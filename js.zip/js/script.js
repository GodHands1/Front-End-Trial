const hamburger = document.querySelector(".hamburger")
const navMenu = document.querySelector(".nav-menu")

if (hamburger && navMenu) {
  hamburger.addEventListener("click", () => {
    hamburger.classList.toggle("active")
    navMenu.classList.toggle("active")
  })

  document.querySelectorAll(".nav-link").forEach((link) => {
    link.addEventListener("click", () => {
      hamburger.classList.remove("active")
      navMenu.classList.remove("active")
    })
  })
}

const faqItems = document.querySelectorAll(".faq-item")
faqItems.forEach((item) => {
  const question = item.querySelector(".faq-question")
  question.addEventListener("click", () => {
    const isActive = item.classList.contains("active")

    faqItems.forEach((faqItem) => {
      faqItem.classList.remove("active")
    })

    if (!isActive) {
      item.classList.add("active")
    }
  })
})

const registerForm = document.getElementById("registerForm")
if (registerForm) {
  registerForm.addEventListener("submit", (e) => {
    e.preventDefault()

    let isValid = true

    clearErrors()

    const fullName = document.getElementById("fullName").value.trim()
    if (!validateFullName(fullName)) {
      showError("fullName", "Please enter a valid full name (at least 2 words)")
      isValid = false
    }

    const email = document.getElementById("email").value.trim()
    if (!validateEmail(email)) {
      showError("email", "Please enter a valid email address")
      isValid = false
    }

    const phone = document.getElementById("phone").value.trim()
    if (!validatePhone(phone)) {
      showError("phone", "Please enter a valid phone number (10-15 digits)")
      isValid = false
    }

    const password = document.getElementById("password").value
    if (!validatePassword(password)) {
      showError("password", "Password must be at least 8 characters with uppercase, lowercase, and number")
      isValid = false
    }

    const confirmPassword = document.getElementById("confirmPassword").value
    if (!validateConfirmPassword(password, confirmPassword)) {
      showError("confirmPassword", "Passwords do not match")
      isValid = false
    }

    const country = document.getElementById("country").value
    if (!validateCountry(country)) {
      showError("country", "Please select your country")
      isValid = false
    }

    const birthDate = document.getElementById("birthDate").value
    if (!validateBirthDate(birthDate)) {
      showError("birthDate", "You must be at least 18 years old")
      isValid = false
    }

    const terms = document.getElementById("terms").checked
    if (!validateTerms(terms)) {
      showError("terms", "You must agree to the Terms of Service")
      isValid = false
    }

    if (isValid) {
      alert("Registration successful! Welcome to CryPIto!")
      registerForm.reset()
    }
  })
}

const inputs = ["fullName", "email", "phone", "password", "confirmPassword", "country", "birthDate"]
inputs.forEach((inputId) => {
  const input = document.getElementById(inputId)
  if (input) {
    input.addEventListener("blur", () => {
      validateField(inputId, input.value)
    })
  }
})

const termsCheckbox = document.getElementById("terms")
if (termsCheckbox) {
  termsCheckbox.addEventListener("change", function () {
    if (this.checked) {
      clearError("terms")
    }
  })
}

function validateFullName(name) {
  if (name.length < 2) return false
  const words = name.split(" ").filter((word) => word.length > 0)
  return words.length >= 2 && words.every((word) => isAlpha(word))
}

function validateEmail(email) {
  if (email.length < 5) return false
  const atIndex = email.indexOf("@")
  const dotIndex = email.lastIndexOf(".")

  return atIndex > 0 && dotIndex > atIndex + 1 && dotIndex < email.length - 1 && email.indexOf("@", atIndex + 1) === -1
}

function validatePhone(phone) {
  const cleanPhone = phone.replace(/\D/g, "")
  return cleanPhone.length >= 10 && cleanPhone.length <= 15
}

function validatePassword(password) {
  if (password.length < 8) return false

  let hasUpper = false
  let hasLower = false
  let hasNumber = false

  for (let i = 0; i < password.length; i++) {
    const char = password[i]
    if (char >= "A" && char <= "Z") hasUpper = true
    if (char >= "a" && char <= "z") hasLower = true
    if (char >= "0" && char <= "9") hasNumber = true
  }

  return hasUpper && hasLower && hasNumber
}

function validateConfirmPassword(password, confirmPassword) {
  return password === confirmPassword && password.length > 0
}

function validateCountry(country) {
  return country.length > 0
}

function validateBirthDate(birthDate) {
  if (!birthDate) return false

  const today = new Date()
  const birth = new Date(birthDate)
  const age = today.getFullYear() - birth.getFullYear()
  const monthDiff = today.getMonth() - birth.getMonth()

  if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birth.getDate())) {
    return age - 1 >= 18
  }

  return age >= 18
}

function validateTerms(terms) {
  return terms === true
}

function isAlpha(str) {
  for (let i = 0; i < str.length; i++) {
    const char = str[i].toLowerCase()
    if (char < "a" || char > "z") {
      return false
    }
  }
  return true
}

function validateField(fieldId, value) {
  let isValid = true
  let errorMessage = ""

  switch (fieldId) {
    case "fullName":
      if (!validateFullName(value)) {
        errorMessage = "Please enter a valid full name (at least 2 words)"
        isValid = false
      }
      break
    case "email":
      if (!validateEmail(value)) {
        errorMessage = "Please enter a valid email address"
        isValid = false
      }
      break
    case "phone":
      if (!validatePhone(value)) {
        errorMessage = "Please enter a valid phone number (10-15 digits)"
        isValid = false
      }
      break
    case "password":
      if (!validatePassword(value)) {
        errorMessage = "Password must be at least 8 characters with uppercase, lowercase, and number"
        isValid = false
      }
      break
    case "confirmPassword":
      const password = document.getElementById("password").value
      if (!validateConfirmPassword(password, value)) {
        errorMessage = "Passwords do not match"
        isValid = false
      }
      break
    case "country":
      if (!validateCountry(value)) {
        errorMessage = "Please select your country"
        isValid = false
      }
      break
    case "birthDate":
      if (!validateBirthDate(value)) {
        errorMessage = "You must be at least 18 years old"
        isValid = false
      }
      break
  }

  if (isValid) {
    clearError(fieldId)
  } else {
    showError(fieldId, errorMessage)
  }
}

function showError(fieldId, message) {
  const field = document.getElementById(fieldId)
  const errorElement = document.getElementById(fieldId + "Error")
  const formGroup = field.closest(".form-group")

  if (errorElement) {
    errorElement.textContent = message
    errorElement.classList.add("show")
  }

  if (formGroup) {
    formGroup.classList.add("error")
  }
}

function clearError(fieldId) {
  const errorElement = document.getElementById(fieldId + "Error")
  const field = document.getElementById(fieldId)
  const formGroup = field.closest(".form-group")

  if (errorElement) {
    errorElement.classList.remove("show")
  }

  if (formGroup) {
    formGroup.classList.remove("error")
  }
}

function clearErrors() {
  const errorElements = document.querySelectorAll(".error-message")
  const formGroups = document.querySelectorAll(".form-group")

  errorElements.forEach((element) => {
    element.classList.remove("show")
  })

  formGroups.forEach((group) => {
    group.classList.remove("error")
  })
}

document.querySelectorAll('a[href^="#"]').forEach((anchor) => {
  anchor.addEventListener("click", function (e) {
    e.preventDefault()
    const target = document.querySelector(this.getAttribute("href"))
    if (target) {
      target.scrollIntoView({
        behavior: "smooth",
        block: "start",
      })
    }
  })
})

document.querySelectorAll(".cta-button, .secondary-button, .submit-button").forEach((button) => {
  button.addEventListener("click", function () {
    this.style.opacity = "0.8"
    setTimeout(() => {
      this.style.opacity = "1"
    }, 200)
  })
})
